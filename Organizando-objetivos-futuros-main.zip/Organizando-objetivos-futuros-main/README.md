# Organizando-objetivos-futuros
ícone Projeto de vida: organizando objetivos futuros com matemática aplicada Projeto de vida: organizando objetivos futuros com matemática aplicada
